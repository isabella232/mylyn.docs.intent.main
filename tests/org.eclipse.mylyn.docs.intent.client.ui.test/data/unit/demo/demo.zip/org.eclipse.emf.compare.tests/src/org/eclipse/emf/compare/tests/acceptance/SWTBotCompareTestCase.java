package org.eclipse.emf.compare.tests.acceptance;

import junit.framework.TestCase;

public class SWTBotCompareTestCase extends TestCase {
	// TODO
}
