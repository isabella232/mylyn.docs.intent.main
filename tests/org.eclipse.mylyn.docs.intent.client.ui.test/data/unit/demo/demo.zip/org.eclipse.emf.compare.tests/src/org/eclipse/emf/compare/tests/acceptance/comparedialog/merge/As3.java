package org.eclipse.emf.compare.tests.acceptance.comparedialog.merge;

public class As3 {
	// TODO
}
