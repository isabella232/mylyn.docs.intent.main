package org.eclipse.emf.compare.tests.acceptance.comparedialog.versionning;

public class As2 {

	public As2() {
		// TODO
	}
}
