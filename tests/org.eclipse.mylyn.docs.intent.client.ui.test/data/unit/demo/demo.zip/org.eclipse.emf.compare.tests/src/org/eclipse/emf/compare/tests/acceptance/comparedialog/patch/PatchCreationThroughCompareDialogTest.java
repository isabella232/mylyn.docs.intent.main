package org.eclipse.emf.compare.tests.acceptance.comparedialog.patch;

import org.eclipse.emf.compare.tests.acceptance.SWTBotCompareTestCase;

public class PatchCreationThroughCompareDialogTest extends SWTBotCompareTestCase {
	// TODO
}
