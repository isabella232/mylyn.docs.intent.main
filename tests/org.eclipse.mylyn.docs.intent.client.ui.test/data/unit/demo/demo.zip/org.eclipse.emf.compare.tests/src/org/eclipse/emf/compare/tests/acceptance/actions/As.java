package org.eclipse.emf.compare.tests.acceptance.actions;

public class As {
	public As() {
		// TODO Auto-generated constructor stub
	}
}
