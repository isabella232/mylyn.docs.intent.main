/*******************************************************************************
 * Copyright (c) 2010, 2011 Obeo.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *     Obeo - initial API and implementation
 *******************************************************************************/
package org.eclipse.myly.docs.intent.java.example;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Class Javadoc.
 * 
 * @author <a href="mailto:alex.lagarde@obeo.fr">Alex Lagarde</a>
 */
public class ExampleJavaClass extends AbstractExampleJavaClass implements IExampleJavaClass {

	/**
	 * staticPublicField Javadoc.
	 */
	static public ExampleJavaClass staticPublicField;

	/**
	 * protectedField Javadoc.
	 */
	protected ExampleJavaClass protectedField;

	/**
	 * privateField Javadoc.
	 */
	private Object privateField;

	/**
	 * private constructor javadoc.
	 */
	private ExampleJavaClass() {
		// Do nothing
	}

	/**
	 * public constructor.
	 * 
	 * @param param1
	 *            param1 javdoc.
	 */
	public ExampleJavaClass(ExampleJavaClass param1) {
		this();
	}

	/**
	 * publicVoidMethod Javadoc.
	 */
	public void publicVoidMethod() {
		// This void method does not return anything
		privateMethodWithReturnType();
	}

	/**
	 * privateMethodWithReturntype.
	 * 
	 * @return returns
	 */
	private ExampleJavaClass privateMethodWithReturnType() throws RuntimeException,
			ArrayIndexOutOfBoundsException {
		return null;
	}

	/**
	 * protectedMethodWithParameters Javadoc.
	 * 
	 * @param param1
	 *            param1
	 * @param param2
	 *            param2
	 * @return returns
	 */
	protected ExampleJavaClass protectedMethodWithParameters(ExampleJavaClass param1, Object param2) {
		return privateMethodWithReturnType();
	}

	Set<ExampleJavaClass> packageVisibleMethodWithCollections(List<ExampleJavaClass> collection,
			Map<ExampleJavaClass, String> map) {
		Set<ExampleJavaClass> collect = new LinkedHashSet<ExampleJavaClass>();
		return collect;
	}
}
